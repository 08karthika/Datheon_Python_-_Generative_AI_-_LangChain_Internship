import json, os
import streamlit as st
from dotenv import load_dotenv
from google import genai
from pydantic import BaseModel, Field

load_dotenv()
st.set_page_config(page_title="LLM JSON Extractor", page_icon="📄")
st.title("LLM Structured Data Extractor")
st.caption("Extract invoice or resume information and validate it as JSON.")

key = os.getenv("GEMINI_API_KEY")
if not key:
    st.error("Gemini API key not found. Add it to your .env file.")
    st.stop()

client = genai.Client(api_key=key)
model = os.getenv("GEMINI_MODEL", "gemini-2.5-flash")

class Invoice(BaseModel):
    invoice_number: str
    invoice_date: str
    vendor_name: str
    customer_name: str
    total_amount: float
    currency: str
    items: list[str]

class Resume(BaseModel):
    full_name: str
    email: str
    phone: str
    skills: list[str]
    education: list[str]
    experience: list[str]

kind = st.selectbox("Document type", ["Invoice", "Resume"])
uploaded = st.file_uploader("Upload a text file", type=["txt"])
pasted = st.text_area("Or paste document text", height=180)

if st.button("Extract information", type="primary"):
    if not uploaded and not pasted.strip():
        st.warning("Upload a .txt file or paste some text.")
        st.stop()
    source = uploaded.getvalue().decode("utf-8") if uploaded else pasted
    schema = Invoice if kind == "Invoice" else Resume
    if kind == "Invoice":
        instruction = "Extract invoice_number, invoice_date, vendor_name, customer_name, total_amount, currency and items. Do not guess. Use Not provided for missing text fields, 0 for amount and [] for items."
        example = 'Example: Invoice INV-101 from ABC Stores to Ravi. Total INR 500. JSON: {"invoice_number":"INV-101","invoice_date":"Not provided","vendor_name":"ABC Stores","customer_name":"Ravi","total_amount":500,"currency":"INR","items":[]}'
    else:
        instruction = "Extract full_name, email, phone, skills, education and experience. Do not invent details. Use Not provided for missing email or phone and [] for missing lists."
        example = 'Example: Anu, anu@example.com, skills Python and SQL. JSON: {"full_name":"Anu","email":"anu@example.com","phone":"Not provided","skills":["Python","SQL"],"education":[],"experience":[]}'
    try:
        with st.spinner("Extracting information..."):
            response = client.models.generate_content(
                model=model, contents=f"{instruction}\n{example}\nDocument:\n{source}",
                config={"response_mime_type":"application/json", "response_schema":schema}
            )
            result = schema.model_validate_json(response.text).model_dump()
        st.success("Extracted and validated successfully!")
        st.json(result)
        st.download_button("Download JSON", json.dumps(result, indent=4),
                           file_name=f"{kind.lower()}_output.json",
                           mime="application/json")
    except Exception as error:
        st.error(f"Extraction failed: {error}")
