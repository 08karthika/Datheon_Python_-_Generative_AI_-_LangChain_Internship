# Structured LLM Prompt Pipeline & JSON Extractor

A Python project that extracts structured information from invoice and resume text using Google Gemini. Pydantic validates the generated JSON.

## Features
- Invoice and resume information extraction
- Gemini API integration
- Structured JSON output and Pydantic validation
- Few-shot prompt examples
- Command-line app and Streamlit interface
- JSON download

## Project files
- `app.py` — command-line application
- `ui.py` — Streamlit web interface
- `requirements.txt` — dependencies
- `.env.example` — API key template
- `sample_invoice.txt`, `sample_resume.txt` — test documents

## Setup (Windows)
1. Install Python 3.10 or newer.
2. Open this folder in VS Code.
3. Create and activate a virtual environment:
   ```bash
   python -m venv venv
   venv\\Scripts\\activate
   ```
4. Install packages:
   ```bash
   pip install -r requirements.txt
   ```
5. Copy `.env.example` to `.env` and add your Gemini API key:
   ```env
   GEMINI_API_KEY=your_actual_api_key
   GEMINI_MODEL=gemini-2.5-flash
   ```
   Never upload `.env` or share your API key.

## Run command-line version
```bash
python app.py invoice sample_invoice.txt
python app.py resume sample_resume.txt
```
The result is printed and saved as `output.json`.

## Run Streamlit version
```bash
streamlit run ui.py
```
Select Invoice or Resume, upload a `.txt` file or paste text, then click **Extract information** to view and download JSON.

## Workflow
1. User provides document text.
2. Few-shot prompt instructions guide Gemini.
3. Gemini returns structured JSON.
4. Pydantic validates the response.
5. The app displays or saves the validated result.

## Technologies
Python, Google Gemini API, google-genai, Pydantic, Streamlit, python-dotenv.

**Note:** Verify extracted information before using it in official records. Avoid uploading confidential documents unless authorized.
