import json, os, sys
from pathlib import Path
from dotenv import load_dotenv
from google import genai
from pydantic import BaseModel, Field

load_dotenv()
API_KEY = os.getenv("GEMINI_API_KEY")
if not API_KEY:
    raise SystemExit("Add GEMINI_API_KEY to your .env file.")

client = genai.Client(api_key=API_KEY)
MODEL = os.getenv("GEMINI_MODEL", "gemini-2.5-flash")

class Invoice(BaseModel):
    invoice_number: str = Field(description="Invoice number")
    invoice_date: str = Field(description="Invoice date")
    vendor_name: str = Field(description="Vendor name")
    customer_name: str = Field(description="Customer name")
    total_amount: float = Field(description="Total amount")
    currency: str = Field(description="Currency")
    items: list[str] = Field(description="Purchased items")

class Resume(BaseModel):
    full_name: str
    email: str
    phone: str
    skills: list[str]
    education: list[str]
    experience: list[str]

def extract_data(text, kind):
    schema = Invoice if kind == "invoice" else Resume
    if kind == "invoice":
        instruction = "Extract invoice_number, invoice_date, vendor_name, customer_name, total_amount, currency and items. Do not guess missing values. Use 'Not provided' for missing text fields, 0 for missing amount and [] for missing items."
        example = 'Example: Invoice INV-101 from ABC Stores to Ravi. Total INR 500. JSON: {"invoice_number":"INV-101","invoice_date":"Not provided","vendor_name":"ABC Stores","customer_name":"Ravi","total_amount":500,"currency":"INR","items":[]}'
    elif kind == "resume":
        instruction = "Extract full_name, email, phone, skills, education and experience. Do not invent details. Use 'Not provided' for missing email or phone and [] for missing lists."
        example = 'Example: Anu, anu@example.com, skills Python and SQL. JSON: {"full_name":"Anu","email":"anu@example.com","phone":"Not provided","skills":["Python","SQL"],"education":[],"experience":[]}'
    else:
        raise ValueError("Choose invoice or resume.")

    prompt = f"{instruction}\n{example}\nDocument:\n{text}"
    response = client.models.generate_content(
        model=MODEL, contents=prompt,
        config={"response_mime_type":"application/json", "response_schema":schema}
    )
    return schema.model_validate_json(response.text).model_dump()

def main():
    if len(sys.argv) != 3:
        print("Usage: python app.py <invoice|resume> <input_file.txt>")
        return
    kind, filename = sys.argv[1].lower(), Path(sys.argv[2])
    if not filename.is_file():
        print("Input file not found.")
        return
    try:
        result = extract_data(filename.read_text(encoding="utf-8"), kind)
        Path("output.json").write_text(json.dumps(result, indent=4), encoding="utf-8")
        print(json.dumps(result, indent=4))
        print("Saved to output.json")
    except Exception as error:
        print("Extraction failed:", error)

if __name__ == "__main__":
    main()
