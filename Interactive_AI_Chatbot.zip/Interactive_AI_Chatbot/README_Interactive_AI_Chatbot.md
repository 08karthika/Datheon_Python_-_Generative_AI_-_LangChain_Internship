# Interactive Full-Stack AI Chatbot with Streamlit

## Project Overview

The **Interactive Full-Stack AI Chatbot** is a web-based conversational
AI application built with Python, Streamlit, LangChain, and the Google
Gemini API.

Users can chat with an AI assistant through a simple web interface. The
application streams responses as they are generated and keeps
conversation history during the active Streamlit session.

## Features

-   **Interactive Chat Interface:** Chat with the AI through a Streamlit
    web application.
-   **Gemini AI Integration:** Generate responses using Google's Gemini
    model.
-   **Streaming Responses:** Display responses progressively as they are
    generated.
-   **Conversation History:** Keep previous user and assistant messages
    in the active session.
-   **Session-Based Memory:** Include earlier messages as context for
    later questions.
-   **Clear Chat:** Reset the current conversation.
-   **Error Handling:** Display errors when an API request fails.

## Technologies Used

  Technology          Purpose
  ------------------- ---------------------------------------------
  Python              Core programming language
  Streamlit           Web application interface
  LangChain           LLM integration and message handling
  Google Gemini API   AI response generation
  python-dotenv       Load the API key from environment variables

## Project Structure

``` text
Interactive_AI_Chatbot/
├── app.py
├── requirements.txt
├── .env
├── .gitignore
└── venv/
```

> Do not upload `.env` or `venv/` to GitHub. The `.gitignore` file
> should exclude them.

## Installation and Setup

### 1. Clone the repository

Replace the placeholder with your GitHub repository URL:

``` bash
git clone YOUR_GITHUB_REPOSITORY_URL
```

### 2. Open the project folder

``` bash
cd Interactive_AI_Chatbot
```

### 3. Create a virtual environment

``` bash
python -m venv venv
```

### 4. Activate the virtual environment

On Windows PowerShell:

``` powershell
.\venv\Scripts\Activate
```

### 5. Install dependencies

``` bash
python -m pip install -r requirements.txt
```

### 6. Configure the Gemini API key

Create a `.env` file in the project folder and add:

``` text
GEMINI_API_KEY=your_actual_gemini_api_key
```

Keep your API key private. Never commit the `.env` file to GitHub.

### 7. Run the application

``` bash
streamlit run app.py
```

The application should open in your default web browser.

## How It Works

1.  The user enters a message in the Streamlit chat input.
2.  The application stores the message in Streamlit session state.
3.  LangChain sends the conversation messages to the Gemini model.
4.  Gemini generates a response.
5.  The response is streamed and displayed in the chat interface.
6.  The assistant response is added to the conversation history.
7.  The user can continue the conversation or clear the chat.

## Conversation Memory

The application uses `st.session_state` to keep conversation messages
while the active Streamlit session continues. Previous messages are sent
as context for later responses.

**Note:** This is session-based memory, not permanent database storage.
Conversation history may be lost when the session resets.

## Learning Outcomes

-   Understanding Large Language Model (LLM) applications.
-   Integrating the Google Gemini API with Python.
-   Using LangChain for model interaction.
-   Building a web interface with Streamlit.
-   Implementing streaming responses.
-   Managing conversation history and session state.
-   Handling API errors and environment variables.

## Future Enhancements

-   Save conversations in a database.
-   Support multiple chat sessions.
-   Add PDF and DOCX document support.
-   Implement Retrieval-Augmented Generation (RAG).
-   Add chat export functionality.
-   Add user authentication.

## Author

**Karthika**\
B.Tech -- Artificial Intelligence and Data Science

## License

This project is developed for educational and portfolio purposes.
