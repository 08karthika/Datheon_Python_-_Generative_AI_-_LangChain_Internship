
import os
import streamlit as st

from dotenv import load_dotenv
from langchain_google_genai import ChatGoogleGenerativeAI
from langchain_core.messages import HumanMessage, AIMessage, SystemMessage


# 1. Load API key
load_dotenv()

API_KEY = os.getenv("GEMINI_API_KEY")


# 2. Configure page
st.set_page_config(
    page_title="AI Chatbot",
    page_icon="🤖",
    layout="centered"
)


# 3. Check API key
if not API_KEY:
    st.error("Gemini API key not found. Check your .env file.")
    st.stop()


# 4. Connect to Gemini
llm = ChatGoogleGenerativeAI(
    model="gemini-3.5-flash-lite",
    google_api_key=API_KEY,
    temperature=0.7
)


# 5. Initialize chat memory
if "messages" not in st.session_state:
    st.session_state.messages = []


# 6. Application heading
st.title("🤖 Interactive AI Chatbot")
st.caption("Powered by Gemini AI and LangChain")


# 7. Sidebar
st.sidebar.title("Chat Settings")
st.sidebar.write("Conversation memory is enabled.")

if st.sidebar.button("Clear Chat"):
    st.session_state.messages = []
    st.rerun()


# 8. Display previous messages
for message in st.session_state.messages:

    with st.chat_message(message["role"]):
        st.markdown(message["content"])


# 9. Get user input
user_input = st.chat_input("Ask me anything...")


if user_input:

    # Display user message
    st.session_state.messages.append({
        "role": "user",
        "content": user_input
    })

    with st.chat_message("user"):
        st.markdown(user_input)


    # 10. Prepare conversation history
    chat_history = [
        SystemMessage(
            content="You are a helpful AI assistant. "
                    "Give clear and simple answers."
        )
    ]

    for message in st.session_state.messages:

        if message["role"] == "user":

            chat_history.append(
                HumanMessage(content=message["content"])
            )

        else:

            chat_history.append(
                AIMessage(content=message["content"])
            )


    # 11. Convert Gemini chunks into normal text
    def generate_text():

        for chunk in llm.stream(chat_history):

            content = chunk.content

            if isinstance(content, str):

                if content:
                    yield content

            elif isinstance(content, list):

                for block in content:

                    if isinstance(block, str):
                        yield block

                    elif isinstance(block, dict):
                        if block.get("type") == "text":
                            text = block.get("text", "")

                            if text:
                                yield text


    # 12. Generate and display response
    with st.chat_message("assistant"):

        try:

            response = st.write_stream(generate_text())

            if response:

                st.session_state.messages.append({
                    "role": "assistant",
                    "content": response
                })

            else:

                st.warning(
                    "Gemini returned an empty response. "
                    "Please try again."
                )

        except Exception as error:

            st.error(f"Something went wrong: {error}")
